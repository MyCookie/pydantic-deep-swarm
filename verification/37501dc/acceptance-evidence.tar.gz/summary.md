Acceptance passed for `37501dc5ba199b669fde261208a130702ff324c2` on Darwin arm64, Python 3.11.16.

Migration: 850 fault occurrences across 38 sites.

Installed lanes: clone: passed (15 cases), wheel: passed (15 cases), asset-stripped: passed (15 cases).

External inference, installed Hermes, live Pi/s6 and containers were not selected. No deployment cutover was performed.

No universal OS network confinement claimed; runtime fixture HTTP is loopback and strictly validated.
